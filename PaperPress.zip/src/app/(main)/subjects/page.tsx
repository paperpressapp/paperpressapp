"use client";

/**
 * Subjects Page - Redesigned with Class Selection Popup
 * 
 * Shows all subjects first, then class selection popup when subject is clicked.
 */

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, X, BookOpen, ChevronRight, Atom, FlaskConical, Leaf, Calculator, Laptop, BookText } from "lucide-react";
import { ScrollView, MainLayout } from "@/components/layout";
import { SUBJECTS } from "@/constants/subjects";
import { CLASSES } from "@/constants/classes";
import { usePaperStore } from "@/stores";
import { Button } from "@/components/ui/button";

// Subject icons mapping
const subjectIcons: Record<string, React.ReactNode> = {
  physics: <Atom className="w-5 h-5" />,
  chemistry: <FlaskConical className="w-5 h-5" />,
  biology: <Leaf className="w-5 h-5" />,
  mathematics: <Calculator className="w-5 h-5" />,
  computer: <Laptop className="w-5 h-5" />,
  english: <BookText className="w-5 h-5" />,
};

export default function SubjectsPage() {
  const router = useRouter();
  const { setClass, setSubject, resetAll } = usePaperStore();

  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [showClassPopup, setShowClassPopup] = useState(false);

  const handleSubjectClick = (subjectId: string) => {
    setSelectedSubjectId(subjectId);
    setShowClassPopup(true);
  };

  const handleClassSelect = (classId: string) => {
    if (!selectedSubjectId) return;

    const subject = SUBJECTS.find((s) => s.id === selectedSubjectId);
    if (subject) {
      setClass(classId as "9th" | "10th" | "11th" | "12th");
      setSubject(subject.name as "Physics" | "Chemistry" | "Biology" | "Mathematics" | "Computer" | "English");
      router.push(`/chapters/${classId}/${selectedSubjectId}`);
    }
  };

  const handleBack = () => {
    resetAll();
    router.push("/home");
  };

  const selectedSubject = SUBJECTS.find((s) => s.id === selectedSubjectId);

  return (
    <MainLayout showBottomNav className="bg-gray-50">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 h-12 flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleBack}
          >
            <ArrowLeft className="w-4 h-4 text-gray-700" />
          </Button>
          <h1 className="font-bold text-base text-gray-900">Select Subject</h1>
          <div className="w-8" />
        </div>
      </header>

      <ScrollView className="flex-1 pb-20">
        <div className="px-4 pt-4">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen className="w-5 h-5 text-[#1E88E5]" />
            <h2 className="text-base font-bold text-gray-900">Select Subject</h2>
          </div>
        </div>

          <div className="px-4 pb-4">
            <div className="grid grid-cols-2 gap-3">
              {SUBJECTS.map((subject) => (
                <Button
                  key={subject.id}
                  variant="ghost"
                  onClick={() => handleSubjectClick(subject.id)}
                  className="group justify-start h-auto bg-white rounded-xl p-4 border border-gray-100 shadow-sm active:scale-[0.98] transition-transform text-left"
                >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center mb-2 shadow-md"
                  style={{
                    backgroundColor: `${subject.color}20`,
                    color: subject.color
                  }}
                >
                  {subjectIcons[subject.id]}
                </div>
                <h3 className="font-semibold text-sm text-gray-900">{subject.name}</h3>
                <p className="text-xs text-gray-500 mt-0.5">{subject.chapterCount} Chapters</p>
              </Button>
            ))}
          </div>
        </div>
      </ScrollView>

      {/* Class Selection Popup */}
      <AnimatePresence>
        {showClassPopup && selectedSubject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              className="absolute inset-0 bg-black/50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowClassPopup(false)}
            />
            <motion.div
              className="relative bg-white rounded-2xl w-full max-w-sm overflow-hidden"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
            >
              <div className="p-4 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{
                        backgroundColor: selectedSubject ? `${selectedSubject.color}15` : '#f3f4f6',
                        color: selectedSubject?.color || '#6b7280'
                      }}
                    >
                      {selectedSubject ? subjectIcons[selectedSubject.id] : null}
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-gray-900">{selectedSubject?.name}</h3>
                      <p className="text-xs text-gray-500">Select your class</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => setShowClassPopup(false)} className="h-8 w-8 rounded-lg">
                    <X className="w-4 h-4 text-gray-600" />
                  </Button>
                </div>
              </div>

              <div className="p-4">
                <p className="text-xs font-medium text-gray-500 mb-3">Available Classes</p>
                <div className="grid grid-cols-2 gap-2">
                  {CLASSES.map((classInfo) => (
                    <motion.button
                      key={classInfo.id}
                      onClick={() => handleClassSelect(classInfo.id)}
                      className="group bg-gray-50 hover:bg-[#1E88E5] rounded-xl p-3 border-2 border-transparent hover:border-[#1E88E5] transition-all text-left"
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-white group-hover:bg-white/20 flex items-center justify-center text-sm font-bold text-gray-700 group-hover:text-white transition-colors">
                          {classInfo.id.replace(/\D/g, "")}
                        </div>
                        <div>
                          <p className="font-bold text-sm text-gray-900 group-hover:text-white transition-colors">
                            {classInfo.name}
                          </p>
                        </div>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>

              <div className="p-4 border-t border-gray-100">
                <Button
                  variant="outline"
                  onClick={() => setShowClassPopup(false)}
                  className="w-full h-10 rounded-xl border border-gray-200 font-medium text-gray-700 text-sm"
                >
                  Cancel
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </MainLayout>
  );
}
