"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { 
  BookOpen, FileText, Crown, Clock, Users, GraduationCap,
  Plus, ChevronRight, Sparkles, Calendar, ArrowRight, Settings
} from "lucide-react";
import { MainLayout } from "@/components/layout";
import { AppLoader } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { getFromLocalStorage } from "@/lib/utils/storage";
import { useAuthStore } from "@/stores/authStore";
import { usePaperStore } from "@/stores";
import { getUsageStats } from "@/lib/premium";
import type { GeneratedPaper } from "@/types";

const CLASSES = [
  { id: '9th', name: 'Class 9th', icon: GraduationCap, color: 'from-blue-500 to-blue-600' },
  { id: '10th', name: 'Class 10th', icon: BookOpen, color: 'from-emerald-500 to-emerald-600' },
  { id: '11th', name: 'Class 11th', icon: Users, color: 'from-violet-500 to-violet-600' },
  { id: '12th', name: 'Class 12th', icon: Crown, color: 'from-amber-500 to-amber-600' },
];

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good Morning";
  if (hour < 17) return "Good Afternoon";
  return "Good Evening";
}

export default function HomePage() {
  const router = useRouter();
  const { isAuthenticated, user, profile } = useAuthStore();
  const { setSubject } = usePaperStore();

  const [userName, setUserName] = useState("Teacher");
  const [instituteName, setInstituteName] = useState("");
  const [recentPapers, setRecentPapers] = useState<GeneratedPaper[]>([]);
  const [usageStats, setUsageStats] = useState({ used: 0, limit: 30, isPremium: false });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      let displayName = "Teacher";
      if (isAuthenticated && profile) {
        displayName =
          profile.full_name?.split(" ")[0] ||
          user?.user_metadata?.full_name?.split(" ")[0] ||
          user?.email?.split("@")[0] ||
          "Teacher";
      } else {
        const stored = localStorage.getItem("paperpress_user_name");
        if (stored) displayName = stored.split(" ")[0];
      }
      setUserName(displayName);
      setInstituteName(localStorage.getItem("paperpress_user_institute") || "");

      const papers = getFromLocalStorage<GeneratedPaper[]>("paperpress_papers", []);
      setRecentPapers(
        papers.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      );

      const stats = getUsageStats();
      setUsageStats({
        used: stats.used === -1 ? 0 : stats.used,
        limit: stats.limit === -1 ? 30 : stats.limit,
        isPremium: stats.isPremium,
      });
    } catch (error) {
      console.error('Failed to load usage stats:', error);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, user, profile]);

  if (isLoading) return <AppLoader message="Loading..." />;

  const recentPaper = recentPapers[0] || null;
  const remainingPapers = usageStats.isPremium ? 'Unlimited' : Math.max(0, usageStats.limit - usageStats.used);

  return (
    <MainLayout showBottomNav className="bg-[#F5F7FA]">
      <div className="relative min-h-screen">
        {/* Background - Using gradient instead of 9.8MB image */}
        <div className="fixed inset-0 bg-gradient-to-br from-gray-100 to-gray-200" />

        {/* Content */}
        <div className="relative z-10">
          {/* Header */}
          <header className="bg-white border-b border-gray-100 sticky top-0 z-50 pt-safe">
            <div className="max-w-md mx-auto px-3 h-11 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img src="/logo.png" alt="PaperPress" className="w-7 h-7 rounded-lg" />
                <span className="font-bold text-sm text-[#111827]">PaperPress</span>
              </div>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => router.push("/settings")}
                className="h-11 w-11 rounded-xl"
              >
                <Settings className="w-5 h-5 text-gray-600" />
              </Button>
            </div>
          </header>

          {/* Scrollable Content */}
          <div className="pb-safe">
            {/* Greeting Section */}
            <div className="px-3 pt-4 pb-3">
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-[#6B7280] mb-1">{getGreeting()}</p>
                    <h1 className="text-xl font-bold text-[#111827] leading-tight">
                      {userName} 👋
                    </h1>
                    {instituteName && (
                      <p className="text-xs text-[#6B7280] mt-1">{instituteName}</p>
                    )}
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1E88E5] to-[#1565C0] flex items-center justify-center overflow-hidden">
                    <img src="/logo.png" alt="PaperPress" className="w-7 h-7" />
                  </div>
                </div>
                
                {/* Quick Stats */}
                <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-gray-100">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
                      <FileText className="w-3 h-3 text-[#1E88E5]" />
                    </div>
                    <div>
                      <p className="text-base font-bold text-[#111827]">{recentPapers.length}</p>
                      <p className="text-xs text-[#6B7280]">Papers Created</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${usageStats.isPremium ? 'bg-amber-50' : 'bg-emerald-50'}`}>
                      <Crown className={`w-3 h-3 ${usageStats.isPremium ? 'text-amber-500' : 'text-emerald-500'}`} />
                    </div>
                    <div>
                      <p className="text-base font-bold text-[#111827]">{remainingPapers}</p>
                      <p className="text-xs text-[#6B7280]">{usageStats.isPremium ? 'Premium' : 'Free Credits'}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Create Paper Button */}
            <div className="px-3 pb-3">
              <Button
                onClick={() => router.push("/subjects")}
                className="w-full h-12 rounded-2xl bg-[#1E88E5] text-white font-semibold text-sm"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create New Paper
                <ArrowRight className="w-3 h-3 ml-2" />
              </Button>
            </div>

            {/* Classes Section */}
            <div className="px-3 pb-3">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-base font-bold text-[#111827]">Select Class</h2>
                <span className="text-xs text-[#6B7280]">Choose your class</span>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                {CLASSES.map((cls, index) => (
                  <motion.button
                    key={cls.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    onClick={() => {
                      setSubject(cls.name.replace('Class ', '') as any);
                      router.push(`/subjects`);
                    }}
                    className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 text-left hover:shadow-md transition-shadow"
                  >
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${cls.color} flex items-center justify-center mb-2`}>
                      <cls.icon className="w-4 h-4 text-white" />
                    </div>
                    <p className="font-semibold text-sm text-[#111827]">{cls.name}</p>
                    <p className="text-xs text-[#6B7280]">Board Exam</p>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Last Paper Card */}
            {recentPaper && (
              <div className="px-3 pb-3">
                <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-sm text-[#111827]">Recent Paper</h3>
                    <span className="text-xs text-[#6B7280]">{new Date(recentPaper.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm text-[#111827]">{recentPaper.title}</p>
                      <p className="text-xs text-[#6B7280]">{recentPaper.subject} • {recentPaper.classId}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-[#1E88E5] font-medium">{recentPaper.totalMarks} Marks</span>
                        <span className="text-xs text-[#6B7280]">•</span>
                        <span className="text-xs text-[#6B7280]">{recentPaper.questionCount} Questions</span>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => router.push(`/paper?id=${recentPaper.id}`)}
                      className="h-10 w-10 rounded-lg bg-[#1E88E5]/10"
                    >
                      <ChevronRight className="w-5 h-5 text-[#1E88E5]" />
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Stats Footer */}
            <div className="px-3 pb-4">
              <div className="bg-gradient-to-r from-[#1E88E5]/5 to-[#1565C0]/5 rounded-xl p-3 border border-[#1E88E5]/10">
                <div className="flex items-center gap-2">
                  <img src="/logo.png" alt="PaperPress" className="w-8 h-8 rounded-lg" />
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-[#111827]">AI-Powered Papers</p>
                    <p className="text-xs text-[#6B7280]">Generate exam papers in seconds</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
