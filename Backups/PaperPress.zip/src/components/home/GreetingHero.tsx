"use client";

interface GreetingHeroProps {
  userName: string;
  instituteName: string;
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good Morning";
  if (hour < 17) return "Good Afternoon";
  return "Good Evening";
}

export function GreetingHero({ userName, instituteName }: GreetingHeroProps) {
  return (
    <div className="mb-5">
      <p className="text-sm text-[#6B7280] font-medium mb-0.5">{getGreeting()}</p>
      <h1 className="text-2xl font-bold text-[#111827] leading-tight">
        {userName} 👋
      </h1>
      {instituteName ? (
        <p className="text-sm text-[#6B7280] mt-1">{instituteName}</p>
      ) : null}
    </div>
  );
}
