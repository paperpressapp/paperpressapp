"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { MainLayout } from "@/components/layout";
import { AppLoader } from "@/components/shared";
import { getFromLocalStorage } from "@/lib/utils/storage";
import { useAuthStore } from "@/stores/authStore";
import { usePaperStore } from "@/stores";
import { getUsageStats } from "@/lib/premium";
import { HomeHeader } from "@/components/home/HomeHeader";
import { GreetingHero } from "@/components/home/GreetingHero";
import { PrimaryActionCard } from "@/components/home/PrimaryActionCard";
import { StatsRow } from "@/components/home/StatsRow";
import { LastPaperCard } from "@/components/home/LastPaperCard";
import { QuickStartRow } from "@/components/home/QuickStartRow";
import { UsageBar } from "@/components/home/UsageBar";
import type { GeneratedPaper } from "@/types";

export default function HomePage() {
  const router = useRouter();
  const { isAuthenticated, user, profile } = useAuthStore();
  const { setSubject } = usePaperStore();

  const [userName, setUserName] = useState("Teacher");
  const [instituteName, setInstituteName] = useState("");
  const [recentPapers, setRecentPapers] = useState<GeneratedPaper[]>([]);
  const [usageStats, setUsageStats] = useState({ used: 0, limit: 30, isPremium: false });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      let displayName = "Teacher";
      if (isAuthenticated && profile) {
        displayName =
          profile.full_name?.split(" ")[0] ||
          user?.user_metadata?.full_name?.split(" ")[0] ||
          user?.email?.split("@")[0] ||
          "Teacher";
      } else {
        const stored = localStorage.getItem("paperpress_user_name");
        if (stored) displayName = stored.split(" ")[0];
      }
      setUserName(displayName);
      setInstituteName(localStorage.getItem("paperpress_user_institute") || "");

      const papers = getFromLocalStorage<GeneratedPaper[]>("paperpress_papers", []);
      setRecentPapers(
        papers.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      );

      const stats = getUsageStats();
      setUsageStats({
        used: stats.used === -1 ? 0 : stats.used,
        limit: stats.limit === -1 ? 30 : stats.limit,
        isPremium: stats.isPremium,
      });
    } catch (_) {
      /* silent */
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, user, profile]);

  if (isLoading) return <AppLoader message="Loading..." />;

  const recentPaper = recentPapers[0] || null;

  const handleSubjectQuickStart = (subjectName: string) => {
    setSubject(subjectName as any);
    router.push("/subjects");
  };

  return (
    <MainLayout showBottomNav className="bg-[#F5F7FA]" topSafe={false}>
      <HomeHeader
        userName={userName}
        onSettingsPress={() => router.push("/settings")}
      />

      <div
        className="flex-1 overflow-auto"
        style={{ paddingTop: "56px", paddingBottom: "96px" }}
      >
        {/* White greeting + action zone */}
        <div className="bg-white px-4 pt-6 pb-5 border-b border-[#F0F2F5]">
          <GreetingHero userName={userName} instituteName={instituteName} />
          <PrimaryActionCard onPress={() => router.push("/subjects")} />
        </div>

        {/* Stats pills */}
        <div className="px-4 mt-4">
          <StatsRow
            papersCount={recentPapers.length}
            freeRemaining={
              usageStats.isPremium ? -1 : Math.max(0, usageStats.limit - usageStats.used)
            }
            isPremium={usageStats.isPremium}
          />
        </div>

        {/* Last paper */}
        <div className="px-4 mt-4">
          <LastPaperCard
            paper={recentPaper}
            onOpen={(id) => router.push(`/paper?id=${id}`)}
            onCreateFirst={() => router.push("/subjects")}
          />
        </div>

        {/* Quick start subjects */}
        <div className="mt-4">
          <QuickStartRow onSubjectPress={handleSubjectQuickStart} />
        </div>

        {/* Usage progress */}
        {!usageStats.isPremium && (
          <div className="px-4 mt-4">
            <UsageBar used={usageStats.used} limit={usageStats.limit} />
          </div>
        )}
      </div>
    </MainLayout>
  );
}
