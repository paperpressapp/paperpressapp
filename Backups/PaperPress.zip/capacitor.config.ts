import type { CapacitorConfig } from '@capacitor/cli';

const isProduction = process.env.NODE_ENV === 'production';

const config: CapacitorConfig = {
  appId: 'com.paperpress.app',
  appName: 'PaperPress',
  webDir: 'out',
  server: {
    androidScheme: 'https',
    ...(isProduction && process.env.CAPACITOR_SERVER_URL
      ? { url: process.env.CAPACITOR_SERVER_URL }
      : {}),
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0,
      launchAutoHide: false,
      showSpinner: false,
      backgroundColor: '#1565C0',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      launchFadeOutDuration: 500,
    },
    StatusBar: {
      style: 'LIGHT',
      backgroundColor: '#1565C0',
    },
    Keyboard: {
      resize: 'body',
      resizeOnFullScreen: true,
    },
  },
  android: {
    backgroundColor: '#1565C0',
  },
};

export default config;
